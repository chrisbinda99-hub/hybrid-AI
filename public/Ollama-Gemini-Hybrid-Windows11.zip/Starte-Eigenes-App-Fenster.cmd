@echo off
setlocal EnableDelayedExpansion
cd /d "%~dp0"
title Ollama + Google Gemini - Eigenes App-Fenster (Windows 11)
color 0B
cls

echo ========================================================
echo   Ollama + Google Gemini Hybrid Workstation (Windows 11)
echo   EIGENE UI IM EIGENEN FENSTER (OHNE BROWSER-LEISTEN)
echo ========================================================
echo.

:: [1/2] Pruefe lokalen Ollama-Dienst
echo [1/2] Pruefe lokalen Ollama-Dienst auf Windows 11...
powershell -NoProfile -Command "$r = try { Invoke-RestMethod -Uri 'http://127.0.0.1:11434/api/tags' -TimeoutSec 2 } catch { $null }; if ($r) { Write-Host ' [OK] Ollama aktiv auf http://127.0.0.1:11434' -ForegroundColor Green; if ($r.models) { $names = ($r.models | ForEach-Object { $_.name }) -join ', '; Write-Host ('      Lokale Modelle: ' + $names) -ForegroundColor Cyan } } else { Write-Host ' [HINWEIS] Ollama laeuft noch nicht. Starten Sie Ollama bei Bedarf ueber das Startmenue oder mit: ollama serve' -ForegroundColor Yellow }"

echo.
echo [2/2] Starte isoliertes Desktop-Fenster...

set "TARGET_URL=http://localhost:3000"
powershell -NoProfile -Command "$code = try { (Invoke-WebRequest -Uri 'http://localhost:3000' -TimeoutSec 1).StatusCode } catch { 0 }; if ($code -ne 200) { exit 1 }" >nul 2>&1
if %errorlevel% neq 0 (
    set "TARGET_URL=https://ais-dev-w3t5uz3x7dtztbghvqcw4x-703552349210.europe-west2.run.app"
)

:: Suche App-Window-Runner (--app Modus fuer komplett randloses App-Fenster ohne URL-Zeile)
set "APP_RUNNER="
if exist "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" set "APP_RUNNER=%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe"
if not defined APP_RUNNER if exist "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" set "APP_RUNNER=%ProgramFiles%\Microsoft\Edge\Application\msedge.exe"
if not defined APP_RUNNER if exist "%ProgramFiles%\Google\Chrome\Application\chrome.exe" set "APP_RUNNER=%ProgramFiles%\Google\Chrome\Application\chrome.exe"
if not defined APP_RUNNER if exist "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" set "APP_RUNNER=%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe"
if not defined APP_RUNNER if exist "%LocalAppData%\Google\Chrome\Application\chrome.exe" set "APP_RUNNER=%LocalAppData%\Google\Chrome\Application\chrome.exe"

if defined APP_RUNNER (
    echo  [OK] Starte isoliertes Windows 11 App-Fenster ohne Browser-Tabs und ohne URL-Leiste...
    start "" "!APP_RUNNER!" --app=!TARGET_URL!
) else (
    echo  [OK] Starte isoliertes Einzelfenster via MSHTA Popout...
    start mshta "javascript:window.open('!TARGET_URL!','HybridWorkstationApp','width=1400,height=920,menubar=0,toolbar=0,location=0,status=0,resizable=1');window.close();" 2>nul || start "" "!TARGET_URL!"
)

echo.
echo Workstation erfolgreich im eigenen Fenster geoeffnet!
timeout /t 2 >nul 2>&1
