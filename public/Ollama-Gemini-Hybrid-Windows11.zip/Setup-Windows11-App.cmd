@echo off
setlocal EnableDelayedExpansion
cd /d "%~dp0"
title Ollama + Google Gemini Hybrid Workstation (Windows 11 Setup)
color 0B
cls

echo ========================================================
echo   Ollama + Google Gemini Hybrid Workstation
echo   Windows 11 Desktop- und Startmenue-Installation
echo ========================================================
echo.

set "SCRIPT_DIR=%~dp0"
set "APP_URL=https://ais-dev-w3t5uz3x7dtztbghvqcw4x-703552349210.europe-west2.run.app"
set "STARTER_CMD=%SCRIPT_DIR%Starte-Eigenes-App-Fenster.cmd"
if not exist "%STARTER_CMD%" set "STARTER_CMD=%SCRIPT_DIR%Starte-Hybrid-Workstation.cmd"
set "ICON_FILE=%SCRIPT_DIR%workstation.ico"

echo [1/3] Pruefe Starter-Skripte...
if exist "%STARTER_CMD%" (
    echo       Starter gefunden: %STARTER_CMD%
) else (
    echo       Nutze Standard-Starter.
)

echo.
echo [2/3] Erstelle Desktop-Verknuepfung...
powershell -NoProfile -Command "$ws = New-Object -ComObject WScript.Shell; $d = [Environment]::GetFolderPath('Desktop'); $s = $ws.CreateShortcut((Join-Path $d 'Ollama + Gemini Hybrid Workstation.lnk')); $s.TargetPath = '%STARTER_CMD%'; $s.WorkingDirectory = '%SCRIPT_DIR%'; if (Test-Path '%ICON_FILE%') { $s.IconLocation = '%ICON_FILE%' }; $s.Description = 'Ollama + Google Gemini Hybrid Workstation'; $s.Save()"
if %errorlevel% equ 0 (
    echo  [OK] Desktop-Verknuepfung erfolgreich angelegt!
) else (
    echo  [INFO] Desktop-Verknuepfung konnte nicht automatisch erstellt werden.
)

echo.
echo [3/3] Erstelle Windows 11 Startmenue-Eintrag...
powershell -NoProfile -Command "$ws = New-Object -ComObject WScript.Shell; $sm = Join-Path ([Environment]::GetFolderPath('StartMenu')) 'Programs'; $s = $ws.CreateShortcut((Join-Path $sm 'Ollama + Gemini Hybrid Workstation.lnk')); $s.TargetPath = '%STARTER_CMD%'; $s.WorkingDirectory = '%SCRIPT_DIR%'; if (Test-Path '%ICON_FILE%') { $s.IconLocation = '%ICON_FILE%' }; $s.Description = 'Ollama + Google Gemini Hybrid Workstation'; $s.Save()"
if %errorlevel% equ 0 (
    echo  [OK] Startmenue-Eintrag erfolgreich registriert!
) else (
    echo  [INFO] Startmenue-Eintrag konnte nicht angelegt werden.
)

echo.
echo ========================================================
echo   Installation erfolgreich abgeschlossen!
echo.
echo   Die Hybrid Workstation ist nun in Windows 11 verankert:
echo   - Als Desktop-Icon: 'Ollama + Gemini Hybrid Workstation'
echo   - Im Windows 11 Startmenue unter Programme
echo ========================================================
echo.
pause
