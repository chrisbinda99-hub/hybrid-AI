@echo off
setlocal EnableDelayedExpansion
cd /d "%~dp0"
title Sicherung nach Laufwerk D: (D:\OllamaKnowledge)
color 0A
cls
echo ========================================================
echo   Ollama Knowledge Vault - Offline-Sync nach Laufwerk D:
echo ========================================================
echo.
powershell -NoProfile -ExecutionPolicy Bypass -Command "$vaultDir = if (Test-Path 'D:\') { 'D:\OllamaKnowledge' } else { 'C:\OllamaKnowledge' }; if (-not (Test-Path $vaultDir)) { New-Item -ItemType Directory -Force -Path $vaultDir | Out-Null }; Write-Host (' [OK] Zielverzeichnis: ' + $vaultDir) -ForegroundColor Green; $url = 'http://localhost:3000/api/knowledge/export/jsonl'; $out = Join-Path $vaultDir 'gemini_knowledge_vault.jsonl'; try { Invoke-RestMethod -Uri $url -OutFile $out -TimeoutSec 5; Write-Host ' [OK] Wissensstand von Server gesichert.' -ForegroundColor Green } catch { Write-Host ' [INFO] Lokaler Server offline, bestehendes Archiv bleibt intakt.' -ForegroundColor Yellow }"
echo.
pause
