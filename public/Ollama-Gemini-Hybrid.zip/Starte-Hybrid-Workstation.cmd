@echo off
setlocal EnableDelayedExpansion
cd /d "%~dp0"
title Ollama + Google Gemini Hybrid Workstation (Windows 11)
color 0B
cls

echo ========================================================
echo   Ollama + Google Gemini Hybrid Workstation (Windows 11)
echo   Universeller Starter mit automatischer Browser-Erkennung
echo ========================================================
echo.

:: [1/2] Pruefe lokalen Ollama-Dienst
echo [1/2] Pruefe lokalen Ollama-Dienst auf Windows 11...
powershell -NoProfile -ExecutionPolicy Bypass -Command "$r = try { Invoke-RestMethod -Uri 'http://127.0.0.1:11434/api/tags' -TimeoutSec 2 } catch { $null }; if ($r) { Write-Host ' [OK] Ollama aktiv auf http://127.0.0.1:11434' -ForegroundColor Green; if ($r.models) { $names = ($r.models | ForEach-Object { $_.name }) -join ', '; Write-Host ('      Erkannte Modelle: ' + $names) -ForegroundColor Cyan } } else { Write-Host ' [HINWEIS] Ollama laeuft noch nicht. Starte Ollama ueber das Startmenue oder mit: ollama serve' -ForegroundColor Yellow }"

echo.
echo [2/2] Automatische Browser-Erkennung (Firefox, Chrome, Edge)...

:: Ziel-Adresse pruefen
set "TARGET_URL=http://localhost:3000"
powershell -NoProfile -Command "$code = try { (Invoke-WebRequest -Uri 'http://localhost:3000' -TimeoutSec 1).StatusCode } catch { 0 }; if ($code -ne 200) { exit 1 }" >nul 2>&1
if %errorlevel% neq 0 (
    set "TARGET_URL=https://ais-dev-w3t5uz3x7dtztbghvqcw4x-703552349210.europe-west2.run.app"
)
echo      Ziel: !TARGET_URL!

:: Automatische Browser-Erkennung (Firefox wird nativ erkannt und bevorzugt)
set "BROWSER_EXE="
set "BROWSER_NAME="
set "BROWSER_ARGS="

:: Registry nach Windows-Standardbrowser abfragen
set "PROGID="
for /f "tokens=3" %%A in ('reg query "HKCU\Software\Microsoft\Windows\Shell\Associations\UrlAssociations\http\UserChoice" /v ProgId 2^>nul ^| findstr /i "ProgId"') do set "PROGID=%%A"

:: Pruefe ob Firefox bevorzugt, aktiv oder Standard ist
set "IS_FF=0"
echo !PROGID! | findstr /i "Firefox" >nul && set "IS_FF=1"
tasklist /fi "imagename eq firefox.exe" 2>nul | findstr /i "firefox.exe" >nul && set "IS_FF=1"

if "!IS_FF!"=="1" (
    if exist "%ProgramFiles%\Mozilla Firefox\firefox.exe" set "BROWSER_EXE=%ProgramFiles%\Mozilla Firefox\firefox.exe"
    if not defined BROWSER_EXE if exist "%ProgramFiles(x86)%\Mozilla Firefox\firefox.exe" set "BROWSER_EXE=%ProgramFiles(x86)%\Mozilla Firefox\firefox.exe"
    if not defined BROWSER_EXE if exist "%LocalAppData%\Mozilla Firefox\firefox.exe" set "BROWSER_EXE=%LocalAppData%\Mozilla Firefox\firefox.exe"
    if defined BROWSER_EXE (
        set "BROWSER_NAME=Mozilla Firefox"
        set "BROWSER_ARGS=-new-window !TARGET_URL!"
    )
)

:: Falls kein Firefox durch Registry, pruefe Chrome / Brave
if not defined BROWSER_EXE (
    echo !PROGID! | findstr /i "Chrome" >nul
    if !errorlevel! equ 0 (
        if exist "%ProgramFiles%\Google\Chrome\Application\chrome.exe" set "BROWSER_EXE=%ProgramFiles%\Google\Chrome\Application\chrome.exe"
        if not defined BROWSER_EXE if exist "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" set "BROWSER_EXE=%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe"
        if not defined BROWSER_EXE if exist "%LocalAppData%\Google\Chrome\Application\chrome.exe" set "BROWSER_EXE=%LocalAppData%\Google\Chrome\Application\chrome.exe"
        if defined BROWSER_EXE (
            set "BROWSER_NAME=Google Chrome"
            set "BROWSER_ARGS=--app=!TARGET_URL!"
        )
    )
)

:: Fallback nach vorhandenen Browser-Installationen (Firefox zuerst!)
if not defined BROWSER_EXE (
    if exist "%ProgramFiles%\Mozilla Firefox\firefox.exe" (
        set "BROWSER_EXE=%ProgramFiles%\Mozilla Firefox\firefox.exe"
        set "BROWSER_NAME=Mozilla Firefox"
        set "BROWSER_ARGS=-new-window !TARGET_URL!"
    ) else if exist "%ProgramFiles(x86)%\Mozilla Firefox\firefox.exe" (
        set "BROWSER_EXE=%ProgramFiles(x86)%\Mozilla Firefox\firefox.exe"
        set "BROWSER_NAME=Mozilla Firefox"
        set "BROWSER_ARGS=-new-window !TARGET_URL!"
    ) else if exist "%LocalAppData%\Mozilla Firefox\firefox.exe" (
        set "BROWSER_EXE=%LocalAppData%\Mozilla Firefox\firefox.exe"
        set "BROWSER_NAME=Mozilla Firefox"
        set "BROWSER_ARGS=-new-window !TARGET_URL!"
    ) else if exist "%ProgramFiles%\Google\Chrome\Application\chrome.exe" (
        set "BROWSER_EXE=%ProgramFiles%\Google\Chrome\Application\chrome.exe"
        set "BROWSER_NAME=Google Chrome"
        set "BROWSER_ARGS=--app=!TARGET_URL!"
    ) else if exist "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" (
        set "BROWSER_EXE=%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe"
        set "BROWSER_NAME=Microsoft Edge"
        set "BROWSER_ARGS=--app=!TARGET_URL!"
    )
)

:: Starten
if defined BROWSER_EXE (
    echo  [OK] Automatisch erkannter Browser: !BROWSER_NAME!
    echo       Starte: "!BROWSER_EXE!" !BROWSER_ARGS!
    start "" "!BROWSER_EXE!" !BROWSER_ARGS!
) else (
    echo  [OK] Starte Windows 11 Standard-Browser (Automatische Systemuebergabe)...
    start "" "!TARGET_URL!"
)

echo.
echo ========================================================
echo   Workstation erfolgreich geoeffnet!
echo ========================================================
timeout /t 3 >nul 2>&1
