@echo off
cd /d "%~dp0"
call Starte-Hybrid-Workstation.cmd
