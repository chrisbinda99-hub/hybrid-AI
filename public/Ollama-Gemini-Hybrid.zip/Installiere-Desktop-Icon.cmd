@echo off
setlocal EnableDelayedExpansion
cd /d "%~dp0"
title Desktop-Verknuepfung erstellen (Automatische Browser-Erkennung)
color 0A
cls

echo ========================================================
echo   Ollama + Google Gemini Hybrid Workstation (Windows 11)
echo   Desktop-Verknuepfung automatisch einrichten
echo ========================================================
echo.

powershell -NoProfile -ExecutionPolicy Bypass -Command "$scriptDir = $PSScriptRoot; if (-not $scriptDir) { $scriptDir = (Get-Location).Path }; $starterBat = Join-Path $scriptDir 'Starte-Hybrid-Workstation.cmd'; $shortcutPath = [Environment]::GetFolderPath('Desktop') + '\Ollama + Gemini Hybrid.lnk'; $wsh = New-Object -ComObject WScript.Shell; $sc = $wsh.CreateShortcut($shortcutPath); if (Test-Path $starterBat) { $sc.TargetPath = $starterBat; $sc.WorkingDirectory = $scriptDir; $sc.Description = 'Ollama + Google Gemini Hybrid Workstation (Automatische Browser-Erkennung)' } else { $sc.TargetPath = 'cmd.exe'; $sc.Arguments = '/c start "" http://localhost:3000'; $sc.Description = 'Ollama + Google Gemini Hybrid Workstation' }; $sc.Save(); Write-Host ' [OK] Desktop-Icon erfolgreich auf Ihrem Windows 11 Desktop angelegt!' -ForegroundColor Green; Write-Host ('      Ziel: ' + $shortcutPath) -ForegroundColor Gray"

echo.
echo ========================================================
echo   Fertig! Sie koennen die Workstation jetzt direkt
echo   ueber das neue Desktop-Icon starten.
echo ========================================================
pause
